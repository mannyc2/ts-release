# Changelog

## Unreleased

## 0.3.0 - 2026-09-01

### Self-release hardening

- Split credential-free preparation, no-upload npm OIDC certification,
  lightweight tag creation, npm publication, and later GitHub publication
  into five exact-SHA dispatch modes. GitHub and npm consume distinct
  content-addressed prepared bundles
  under separately named environments and least-privilege job permissions;
  no default path receives publication authority.
- Pin GitHub-hosted runner labels, third-party Actions, Node 22.22.2, Bun
  1.3.14, and the self-release npm CLI at 11.11.0. Reauthenticate the exact
  checkout against the current public `main` tip immediately before every
  preparation or publication boundary, and reject ambient npm credentials.
- After npm publication, bind the adopted tarball bytes to registry integrity,
  the exact GitHub SLSA v1 provenance statement and run identity, and npm's
  cryptographic signature audit. Select same-run proof for a fresh mutation
  and authenticate the provenance-named prior run for an exact
  `AlreadyEquivalent` response-loss recovery. Pin Sigstore 4.1.0 from the
  audited npm archive and require the exact Fulcio workflow SAN, OIDC issuer,
  environment-bound ID-qualified repository subject, source/workflow SHA, and
  run-invocation certificate extensions. Preserve
  GitHub tag, release, and asset equivalence checks inside the provider-native
  publisher.
- Keep every credentialed job free of nonlocal Actions by natively checking
  out the exact current-main candidate and executing its local Action. Stage
  GitHub assets only in a private draft; a fresh later full asset reread is the
  sole authority for PATCH-only public promotion. Bind trusted npm children to
  an empty private home and explicit empty mode-0600 user/global configs.
- Move final npm certification/publication evidence out of the `id-token:
  write` producer jobs. A dependency-free Node bootstrap validates then drops
  the runner-injected OIDC request authority, binds the exact private report,
  and commits one explicitly non-final handoff. A separate no-environment,
  no-id-token job verifies that artifact and alone retains the final v2
  receipt; missing outputs, changed attempts, and unknown writes fail closed.

### Canonical operation journal

- Add a provider-neutral `operation-journal` subpath with one opaque canonical
  event envelope, one finite transition reducer, and one versioned S3
  conditional-write protocol. Durable acknowledgments require exact retained
  event/head re-read and full-chain validation; response loss, CAS conflict,
  and fresh-process orphan recovery are bounded and fail closed. Every retained
  attempt that shares a transaction ID must carry the same opaque logical
  record and workflow, including attempts already reachable from the head.
- Keep provider codecs and provider calls outside the journal package boundary.
  Add the sole package-owned `operation-journal/aws` adapter: it rejects
  ambient AWS configuration, exchanges a GitHub OIDC token directly for one
  short-lived role session, re-observes STS/IAM/S3 authority, parses the exact
  role/trust/bucket policies, and emits only single-part conditional S3 writes.
  Serialized SDK requests and fakes qualify this code without claiming live
  AWS policy or retained-object qualification. No SQLite, Git ref, Actions
  artifact, alternate endpoint, credential chain, or fallback store is added.
- Bind caller and called reusable-workflow OIDC refs and source SHAs as
  distinct claims, derive event run coordinates from the observed session, and
  include the exact OIDC trust-policy digest in authority drift checks. Pin the
  called workflow at one immutable commit, admit one frozen name- or
  immutable-ID-bound environment subject, and locally require hosted public
  workflow-dispatch branch claims from the same STS-admitted token. Bound every
  OIDC fetch, AWS SDK send, and object stream by a fixed wall-clock deadline.
  Operation identities, payloads, retained objects, request/response
  coordinates, and JWT bytes are independently bounded, and Actions request
  coordinates are consumed from the environment before use. The
  checked-in reusable workflow remains permissionless and always fails until a
  released adapter, exact infrastructure, opaque-byte call topology, and live
  retained-object protocol are separately qualified.

### PyPI embedded-binary distributions

- Reopen the repository-specific PyPI wrapper-wheel decision with four
  deterministic `ts-release` wheels: manylinux 2.17 and macOS 13, each for
  x64 and arm64. Every wheel embeds exactly one Bun-compiled executable and
  exposes the `ts-release` Python console script.
- Add an isolated manual PyPI workflow. Its build job has read-only repository
  authority; its separate `pypi` environment job grants only `id-token: write`
  and invokes `pypa/gh-action-pypi-publish@release/v1` over the transferred
  four-wheel artifact set.
- Make native self-release builds use the version-bearing Bun entrypoint and
  require the Linux candidate executable to report the exact manifest version.

## 0.2.2 - 2026-08-14

This release delivers the intended `0.2` product relative to `0.0.7` and
supersedes the incomplete immutable `v0.2.1` release.

### npm release repair

- Preserve the canonical, digest-only prepared-store blob as the admitted npm
  publication input, while materializing its exact bytes through a private,
  mode-0600 `.tgz` transport path only for the lifetime of the npm process.
  npm treats a suffixless local path as a package directory; the scoped alias
  gives npm the required file classification without weakening prepared-bundle
  validation or leaving transport bytes behind after success, failure, or
  interruption.

## 0.2.1 - incomplete (2026-08-14)

The immutable GitHub tag, release, and configured assets were created, but npm
did not publish because npm classified the verified digest-only blob path as a
directory. Those subjects remain an audit record and are superseded by
`0.2.2`; no `0.2.1` subject was rewritten. This candidate otherwise contained
the following release content and repairs.

### Release repair

- Preserve caller-declared HTTP body media types through the Effect transport,
  so GitHub agent archives retain `application/zip` instead of being rewritten
  to `application/octet-stream`.
- Authenticate recovery against the canonical workflow path and `head_branch`
  fields returned by GitHub's run-attempt API, allowing an emitted immutable
  prepared reference to be reloaded in a later workflow run.

### Release lifecycle

- Replaced the previous `ship` and plan/apply/review command model with one
  lifecycle: `release`, `prepare`, `inspect`, `observe`, `publish`, and
  `correct`. The same lifecycle is available through the Promise API, CLI, and
  GitHub Action.
- Added complete, content-addressed `prepared-release/v2` bundles. Preparation
  materializes the exact verified commit, binds declared source inputs, checks
  the manifest and blobs, and commits the durable bundle only when every
  declared output is present.
- Added one-command local release and a one-job automatic GitHub Actions path.
  Protected-environment publication remains an optional two-job host workflow,
  not an identity inside ts-release.
- Added a strict `bun-npm-github` init preset that discovers the canonical
  repository coordinate and writes explicit npm and GitHub authentication
  intent.

### Publication, authentication, and recovery

- Retained npm publication and restored explicit trusted-publishing intent.
  npm authentication must select GitHub Actions OIDC or a named token
  credential; credential values remain host-owned and do not enter
  configuration, prepared bytes, reports, or logs.
- Retained GitHub Releases and asset publication with exact tag, commit,
  release, and asset observation before mutation.
- Publication now observes every destination before writing. Equivalent
  subjects are skipped, conflicts stop, and inconclusive pre-mutation reads do
  not acquire credentials. A response-lost write remains uncertain until an
  exact later observation converges.
- Recovery always reloads and verifies the same prepared bundle. It never
  rebuilds from the current checkout as a fallback. Reports preserve partial
  and uncertain outcomes and are redacted before a workflow uploads them.
- Correction is now proposal-only for the installed npm and GitHub providers.
  `correct` binds intent to an exact prepared subject and emits a canonical
  external-operator proposal; it does not delete or mutate provider state.

### Executable capabilities

- Retained Bun compilation, prebuilt-file imports, declared command checks and
  artifact generation, archives, and checksums behind strict configuration and
  default runtime layers.
- Separated execution-host claims from artifact-target claims. Linux is the
  only execution host, the advertised targets are Linux/macOS x64/arm64, and
  Windows is neither an execution host nor a shipped target.
- Added generated capability, recovery-profile, and agent-bundle evidence so a
  documented support row must join to executable code and tests.

### Breaking removals and migration

- Removed the old `ship`, plan/apply/review, approval, and self-review
  protocols. Migrate automation to `release`, or cross an explicit boundary
  with `prepare` followed by `publish` of the returned prepared reference.
- Replaced implicit npm credential selection with explicit
  `publish.npm.authentication`. Existing token workflows must name their
  environment credential; GitHub-hosted trusted publishing must author its
  exact attestation relationship.
- Installed Node consumers now require
  `^22.22.2 || ^24.15.0 || >=26.0.0`. The checked-in GitHub Action is now a
  native Node 24 launcher around a Linux/Bun boundary: advertised workflows
  install pinned Bun, the runtime preloader receives no credentials, and the
  Bun release child receives the runner's Actions-artifact transport. Artifact
  upload/download is executed by a checked-in Node 24 bridge so the official
  client uses native Node streams; bridge requests never serialize the GitHub
  token. This does not change the installed library or CLI's Node engine.
- PyPI prebuilt publication is temporarily removed despite being available in
  `0.0.7`; it is assigned to a post-`0.2.2` provider-capability wave. PyPI
  wrapper wheels are also removed, and will return only after an explicit
  product decision based on native-wheel or cibuildwheel-class user demand.
- Homebrew tap and Scoop bucket rendering and delivery are temporarily removed
  despite being available in `0.0.7`; they are assigned to a separate catalog
  delivery wave. Old PyPI, Homebrew, Scoop, and generic catalog configurations
  are rejected rather than accepted as no-ops.
- A third-party publication-adapter SDK is not part of `0.2.2`. Local extension
  work must use declared command checks or artifact bytes; downstream effects
  belong in the workflow host after a complete release report.

## 0.2.0 - incomplete (2026-08-14)

The immutable GitHub tag and release were created, but asset publication did
not complete and npm was not published. Those immutable subjects remain as an
audit record and are superseded by `0.2.1`; no `0.2.0` subject was rewritten.
