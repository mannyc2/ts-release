import * as Layer from "effect/Layer"
import type { ReleaseRuntimeShape } from "./api/runtime.js"
import { ReleaseRuntime } from "./api/runtime.js"
import type { ReleaseApiLayer } from "./api/types.js"
import type { RunCommand } from "./drivers/process.js"
import { Sha256Digest, sha256Digest } from "./model/digest.js"
import { SafeRelativePath, WorkspaceRoot } from "./model/primitives.js"
import type { CredentialRequest } from "./model/authority.js"
import {
  CredentialAudienceMismatch,
  CredentialProvider,
  CredentialPurposeMismatch,
  CredentialStrategyUnsupported,
  CredentialSubjectMismatch,
  CredentialUnavailable,
  makeCredentialProvider,
  type CredentialAuthorityError,
  type CredentialGrant,
  type CredentialGrantAcquirer,
  type CredentialGrantDescriptor,
  type CredentialProviderShape,
  type MutationCredentialGrant
} from "./publication/authority.js"
import {
  AuthorizedMutationHttp,
  HttpAuthorizer,
  type AuthorizedMutationHttpShape,
  type HttpAuthorizationError,
  type HttpAuthorizerShape,
  type HttpObservationRequest,
  type HttpResponse
} from "./publication/http.js"
import {
  CertifiedPublisherSpawn,
  NpmUserConfigResource,
  type CertifiedPublisherSpawnShape,
  type NpmUserConfigResourceShape
} from "./publication/publisher.js"
import {
  PublicationClaimOccupied,
  PublicationClaimRequest,
  PublicationClaimStore,
  PublicationClaimUnavailable,
  type PublicationClaimError,
  type PublicationClaimStoreShape
} from "./publication/claim.js"
import {
  ReleaseContextError,
  SourceMaterializationError,
  StagingEntry,
  StagingSnapshot,
  VerifiedSource,
  makeSourceObserver,
  type SourceObserverRuntime,
  type SourceObserverShape,
  type VerifiedReleaseContext
} from "./release/context.js"
import {
  PreparedReleaseStore,
  type PreparedReleaseStoreShape
} from "./release/prepared-store.js"

export {
  CredentialAudienceMismatch,
  CredentialPurposeMismatch,
  CredentialStrategyUnsupported,
  CredentialSubjectMismatch,
  CredentialUnavailable,
  PublicationClaimOccupied,
  PublicationClaimRequest,
  PublicationClaimUnavailable,
  ReleaseContextError,
  SafeRelativePath,
  Sha256Digest,
  SourceMaterializationError,
  StagingEntry,
  StagingSnapshot,
  VerifiedSource,
  WorkspaceRoot,
  makeCredentialProvider,
  makeSourceObserver,
  sha256Digest
}

export type {
  CredentialAuthorityError,
  CredentialGrant,
  CredentialGrantAcquirer,
  CredentialGrantDescriptor,
  CredentialProviderShape,
  CredentialRequest,
  HttpAuthorizationError,
  HttpAuthorizerShape,
  HttpObservationRequest,
  HttpResponse,
  AuthorizedMutationHttpShape,
  CertifiedPublisherSpawnShape,
  NpmUserConfigResourceShape,
  PublicationClaimError,
  PublicationClaimStoreShape,
  MutationCredentialGrant,
  ReleaseRuntimeShape,
  RunCommand,
  SourceObserverRuntime,
  SourceObserverShape,
  VerifiedReleaseContext
}

/** Structural inputs for a library-owned host integration. */
export interface CustomReleaseLayerInput {
  readonly runtime: ReleaseRuntimeShape
  readonly preparedStore: PreparedReleaseStoreShape
  readonly credentialProvider: CredentialProviderShape
  readonly httpAuthorizer: HttpAuthorizerShape
  readonly authorizedMutationHttp: AuthorizedMutationHttpShape
  readonly npmUserConfigResource: NpmUserConfigResourceShape
  readonly certifiedPublisherSpawn: CertifiedPublisherSpawnShape
  /** Required before a durable-cas-required publication can acquire mutation credentials. */
  readonly publicationClaimStore?: PublicationClaimStoreShape
}

/**
 * Compose the complete API service boundary without exposing Context service
 * tags. Credentials remain opaque grants and HTTP authorization remains a
 * host-owned elimination boundary.
 */
export const makeCustomReleaseLayer = (
  input: CustomReleaseLayerInput
): ReleaseApiLayer => Layer.mergeAll(
  Layer.succeed(ReleaseRuntime, input.runtime),
  Layer.succeed(PreparedReleaseStore, input.preparedStore),
  Layer.succeed(CredentialProvider, input.credentialProvider),
  Layer.succeed(HttpAuthorizer, input.httpAuthorizer),
  Layer.succeed(AuthorizedMutationHttp, input.authorizedMutationHttp),
  Layer.succeed(NpmUserConfigResource, input.npmUserConfigResource),
  Layer.succeed(CertifiedPublisherSpawn, input.certifiedPublisherSpawn),
  ...(input.publicationClaimStore === undefined
    ? []
    : [Layer.succeed(PublicationClaimStore, input.publicationClaimStore)])
)
