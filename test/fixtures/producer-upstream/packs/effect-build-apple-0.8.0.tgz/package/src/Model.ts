import { Schema } from "effect";
import { Artifact } from "effect-build";

export const App = Schema.Struct({ ...Artifact.Directory.fields, product: Schema.Literal("app") }).check(Schema.makeFilter((value) => Schema.is(Artifact.Directory)(value) ? undefined : "invalid directory artifact"));
export type App = typeof App.Type;
export const Dmg = Schema.Struct({ ...Artifact.File.fields, product: Schema.Literal("dmg") });
export type Dmg = typeof Dmg.Type;
export const Pkg = Schema.Struct({ ...Artifact.File.fields, product: Schema.Literal("pkg") });
export type Pkg = typeof Pkg.Type;
export const Product = Schema.Union([App, Dmg, Pkg]);
export type Product = typeof Product.Type;
const signature = { certificateSha1: Schema.String, secureTimestamp: Schema.Literal(true) };
export const SignedApp = Schema.Struct({ ...App.fields, signature: Schema.Struct({ ...signature, hardenedRuntime: Schema.Literal(true) }) }).check(Schema.makeFilter((value) => Schema.is(App)(value) ? undefined : "invalid app artifact"));
export type SignedApp = typeof SignedApp.Type;
export const SignedDmg = Schema.Struct({ ...Dmg.fields, signature: Schema.Struct(signature) });
export type SignedDmg = typeof SignedDmg.Type;
export const SignedPkg = Schema.Struct({ ...Pkg.fields, signature: Schema.Struct(signature) });
export type SignedPkg = typeof SignedPkg.Type;
export const SignedProduct = Schema.Union([SignedApp, SignedDmg, SignedPkg]);
export type SignedProduct = typeof SignedProduct.Type;
/** A standalone Mach-O executable signed with the hardened runtime; ZIP-notarizable, never stapled. */
export const SignedExecutable = Schema.Struct({ ...Artifact.Executable.fields, signature: Schema.Struct({ ...signature, hardenedRuntime: Schema.Literal(true) }) }).check(Schema.makeFilter((value) => Schema.is(Artifact.Executable)(value) ? undefined : "invalid executable artifact"));
export type SignedExecutable = typeof SignedExecutable.Type;
export const Signed = Schema.Union([SignedApp, SignedDmg, SignedPkg, SignedExecutable]);
export type Signed = typeof Signed.Type;
