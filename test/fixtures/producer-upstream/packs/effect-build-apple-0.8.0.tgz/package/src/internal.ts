import { Effect, FileSystem, Path } from "effect";
import { Artifact, Executable, Tool } from "effect-build";
import { Apple, type Env } from "./Apple.js";
import type { Product } from "./Model.js";
import { plist } from "./plist.js";

export type NativeTool = "codesign" | "hdiutil" | "plutil" | "pkgbuild" | "productbuild" | "productsign" | "pkgutil" | "notarytool" | "stapler" | "spctl" | "ditto";
export const runNative = (name: NativeTool, args: readonly string[], options: Tool.RunOptions = {}): Effect.Effect<
  Tool.Completion, Tool.Failed | Tool.SpawnFailed, Apple | Env
> => Apple.use(({ tool }) => Tool.run(tool, [name, ...args], options));

export const outputPath = (operation: string, value: string, extension: ".app" | ".dmg" | ".pkg" | undefined, cwd?: string) => Effect.gen(function*() {
  const issue = Tool.argumentIssue(value);
  if (issue !== undefined) return yield* new Tool.InputInvalid({ operation, reason: `output ${issue}` });
  const cwdIssue = cwd === undefined ? undefined : Tool.argumentIssue(cwd);
  if (cwdIssue !== undefined) return yield* new Tool.InputInvalid({ operation, reason: `cwd ${cwdIssue}` });
  if (extension !== undefined && !value.toLowerCase().endsWith(extension)) {
    return yield* new Tool.InputInvalid({ operation, reason: `output must end in ${extension}` });
  }
  const p = yield* Path.Path;
  return p.resolve(cwd ?? "", value);
});

export const copyRegular = (artifact: Artifact.Regular, destination: string, executable = artifact.kind === "executable") => Effect.gen(function*() {
  const fs = yield* FileSystem.FileSystem;
  const p = yield* Path.Path;
  yield* Artifact.copy(artifact, destination);
  if (artifact.kind === "executable") {
    yield* Executable.inspect(destination).pipe(
      Effect.flatMap((facts) => Executable.resolveTarget(destination, facts, artifact.target)),
      Effect.mapError((error) => new Artifact.ArtifactError({ path: destination, reason: "invalid-metadata", detail: String(error) })),
    );
  }
  // An in-place destination keeps its own mode.
  if (p.resolve(artifact.path) !== p.resolve(destination)) {
    yield* fs.chmod(destination, executable ? 0o755 : 0o644).pipe(Effect.mapError(Artifact.ioError(destination, "write")));
  }
});
export const copyProduct = (operation: string, artifact: Artifact.Artifact, destination: string, options: Tool.EnvironmentOptions = {}): Effect.Effect<
  void, Tool.InputInvalid | Artifact.ArtifactError | Tool.Failed | Tool.SpawnFailed, Apple | Env
> => Effect.gen(function*() {
  if (artifact.kind !== "directory") return yield* copyRegular(artifact, destination);
  const fs = yield* FileSystem.FileSystem;
  const p = yield* Path.Path;
  const source = yield* fs.realPath(artifact.path).pipe(Effect.mapError(Artifact.ioError(artifact.path)));
  // Resolve missing output components too: a symlinked parent can otherwise copy an app inside itself.
  const missing: string[] = [];
  let destinationRoot = p.resolve(destination);
  while (true) {
    const existing = yield* fs.realPath(destinationRoot).pipe(
      Effect.catchIf((error) => error.reason._tag === "NotFound", () => Effect.succeed(undefined)),
      Effect.mapError(Artifact.ioError(destinationRoot)),
    );
    if (existing !== undefined) {
      destinationRoot = p.join(existing, ...missing);
      break;
    }
    const parent = p.dirname(destinationRoot);
    if (parent === destinationRoot) return yield* new Artifact.ArtifactError({ path: destination, reason: "unreadable" });
    missing.unshift(p.basename(destinationRoot));
    destinationRoot = parent;
  }
  if (source === destinationRoot) return;
  if (source.startsWith(`${destinationRoot}${p.sep}`) || destinationRoot.startsWith(`${source}${p.sep}`)) {
    return yield* new Tool.InputInvalid({ operation, reason: "app copy source and destination must not contain one another" });
  }
  yield* fs.makeDirectory(p.dirname(destination), { recursive: true }).pipe(Effect.mapError(Artifact.ioError(destination, "write")));
  yield* fs.remove(destination, { recursive: true, force: true }).pipe(Effect.mapError(Artifact.ioError(destination, "write")));
  // ditto preserves framework symlinks verbatim; Node's recursive copy can rewrite them toward the source tree.
  yield* runNative("ditto", [artifact.path, destination], options);
});
/** Entitlements arrive as a plist artifact or as keys; both are linted as the file codesign receives. */
export type Entitlements = Artifact.Regular | readonly string[];
export const entitlementsFile = (operation: string, entitlements: Entitlements | undefined, path: string, options: Tool.EnvironmentOptions = {}): Effect.Effect<
  string | undefined, Tool.InputInvalid | Artifact.ArtifactError | Tool.Failed | Tool.SpawnFailed, Apple | Env
> => Effect.gen(function*() {
  if (entitlements === undefined) return undefined;
  if (Array.isArray(entitlements)) {
    const keys = entitlements as readonly string[];
    if (keys.length === 0 || keys.some((key) => Tool.argumentIssue(key) !== undefined || key.trim() !== key) || new Set(keys).size !== keys.length) {
      return yield* new Tool.InputInvalid({ operation, reason: "entitlement keys must be distinct, trimmed, non-empty, and contain no NUL" });
    }
    const fs = yield* FileSystem.FileSystem;
    yield* fs.writeFileString(path, plist(Object.fromEntries(keys.map((key) => [key, true as const])))).pipe(Effect.mapError(Artifact.ioError(path, "write")));
  } else {
    yield* copyRegular(entitlements as Artifact.Regular, path);
  }
  yield* runNative("plutil", ["-lint", path], options);
  return path;
});
/** Describe the mutated product without carrying old signatures, receipts, or digests. */
export const inspectProduct = (product: Product, path: string): Effect.Effect<Product, Artifact.ArtifactError, Apple | Env> => Effect.gen(function*() {
  const { tool } = yield* Apple;
  return product.product === "app"
    ? { ...yield* Artifact.directory(path, Tool.producedBy(tool)), product: "app" as const }
    : { ...yield* Artifact.file(path, Tool.producedBy(tool)), product: product.product };
});
