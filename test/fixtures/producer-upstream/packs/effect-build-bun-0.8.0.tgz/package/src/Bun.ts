import { Context, Effect, FileSystem, Path, Schema } from "effect";
import { ChildProcess, ChildProcessSpawner } from "effect/unstable/process";
import { Artifact, Commit, Executable, Target, Tool } from "effect-build";

export class Bun extends Context.Service<Bun, Tool.Service>()("effect-build-bun/Bun") {}

const collision: readonly Tool.Constraint[] = [{ range: "1.4.1", reason: "variable-collision defect in emitted builds" }];
export const { name, layer, supported, tested, constraints, requirements, resolved, testLayer } = Tool.provider(Bun, {
  name: "bun",
  version: { parse: Tool.versionPattern(/^(?:bun )?(\S+)/u), supported: ">=1.3.14 <2.0.0", tested: ["1.3.14", "1.4.2"] },
  constraints: { "Bun.compile": collision, "Bun.bundle": collision, "Bun.build": collision, "Bun.watch": collision },
  requirements: { env: ["HOME", "BUN_INSTALL_CACHE_DIR", "BUN_INSTALL", "TMPDIR"], network: true, services: [],
    detail: "Cross-compilation downloads an uncached target runtime; project configuration and inlined environment remain inputs." },
});
/**
 * Hardened-runtime entitlements Bun documents for its compiled executables: the
 * JavaScript engine needs JIT and dynamic-library allowances to start once signed.
 * Pass to `Apple.sign({ artifact, entitlements: Bun.entitlements })`.
 */
export const entitlements: readonly string[] = [
  "com.apple.security.cs.allow-jit",
  "com.apple.security.cs.allow-unsigned-executable-memory",
  "com.apple.security.cs.disable-executable-page-protection",
  "com.apple.security.cs.allow-dyld-environment-variables",
  "com.apple.security.cs.disable-library-validation",
];

/** Bun's own target names, for people who want the variants (`-baseline`, `-modern`). */
export const BunTarget = Schema.Literals([
  "bun-linux-x64", "bun-linux-x64-baseline", "bun-linux-x64-modern", "bun-linux-x64-musl",
  "bun-linux-arm64", "bun-linux-arm64-musl",
  "bun-darwin-x64", "bun-darwin-x64-baseline", "bun-darwin-arm64",
  "bun-windows-x64", "bun-windows-x64-baseline", "bun-windows-x64-modern", "bun-windows-arm64",
] as const);
export type BunTarget = typeof BunTarget.Type;

const toBunTarget = (t: Target.Target | BunTarget): BunTarget => t.startsWith("bun-") ? t as BunTarget : `bun-${t}` as BunTarget;
const toTarget = (t: BunTarget): Target.Target =>
  t.replace(/^bun-/, "").replace(/-(baseline|modern)$/, "") as Target.Target;

export interface MinifyOptions {
  readonly syntax?: boolean | undefined;
  readonly whitespace?: boolean | undefined;
  readonly identifiers?: boolean | undefined;
  readonly keepNames?: boolean | undefined;
}

export interface CompileOptions {
  readonly minify?: boolean | MinifyOptions | undefined;
  readonly sourcemap?: "inline" | "none" | undefined;
  readonly bytecode?: boolean | undefined;
  readonly packages?: "bundle" | "external" | undefined;
  readonly external?: readonly string[] | undefined;
  readonly conditions?: readonly string[] | undefined;
  readonly define?: Readonly<Record<string, string>> | undefined;
  readonly environmentInline?: "inline" | "disable" | `${string}*` | undefined;
  readonly execArgv?: readonly string[] | undefined;
  readonly autoloadDotenv?: boolean | undefined;
  readonly autoloadBunfig?: boolean | undefined;
  readonly autoloadTsconfig?: boolean | undefined;
  readonly autoloadPackageJson?: boolean | undefined;
  readonly windows?: {
    readonly hideConsole?: boolean | undefined;
    readonly icon?: string | undefined;
    readonly title?: string | undefined;
    readonly publisher?: string | undefined;
    readonly version?: string | undefined;
    readonly description?: string | undefined;
    readonly copyright?: string | undefined;
  } | undefined;
}

export interface CompileInput extends Commit.ProducerOptions, Tool.EnvironmentOptions {
  readonly entrypoints: readonly [string, ...string[]];
  readonly outfile: string;
  /** Default: the host. */
  readonly target?: Target.Target | BunTarget | undefined;
  readonly cwd?: string | undefined;
  readonly options?: CompileOptions | undefined;
  readonly onOutput?: Tool.RunOptions["onOutput"] | undefined;
}

export type CompileError =
  | Tool.InputInvalid
  | Tool.VersionUnsupported
  | Tool.Failed
  | Tool.SpawnFailed
  | Artifact.ArtifactError
  | Executable.InspectError
  | Executable.TargetMismatch
  | Commit.CommitError;

const renderBoolean = (flag: string, value: boolean | undefined): string[] =>
  value === undefined ? [] : [`--${value ? "" : "no-"}${flag}`];

const renderMinify = (minify: boolean | MinifyOptions | undefined): string[] => [
  ...(minify === true ? ["--minify"] : []),
  ...(typeof minify === "object" && minify.syntax === true ? ["--minify-syntax"] : []),
  ...(typeof minify === "object" && minify.whitespace === true ? ["--minify-whitespace"] : []),
  ...(typeof minify === "object" && minify.identifiers === true ? ["--minify-identifiers"] : []),
  ...(typeof minify === "object" && minify.keepNames === true ? ["--keep-names"] : []),
];

const renderArgv = (input: CompileInput, out: string, target?: BunTarget): string[] => {
  const o = input.options ?? {};
  return [
    "build", "--compile", ...(target === undefined ? [] : [`--target=${target}`]),
    ...renderMinify(o.minify),
    ...(o.sourcemap ? [`--sourcemap=${o.sourcemap}`] : []),
    ...(o.bytecode ? ["--bytecode"] : []),
    ...(o.packages === undefined ? [] : [`--packages=${o.packages}`]),
    ...(o.external ?? []).map((e) => `--external=${e}`),
    ...(o.conditions ?? []).map((e) => `--conditions=${e}`),
    ...Object.entries(o.define ?? {}).flatMap(([k, v]) => ["--define", `${k}=${v}`]),
    ...(o.environmentInline === undefined ? [] : [`--env=${o.environmentInline}`]),
    ...(o.execArgv ?? []).map((value) => `--compile-exec-argv=${value}`),
    ...renderBoolean("compile-autoload-dotenv", o.autoloadDotenv),
    ...renderBoolean("compile-autoload-bunfig", o.autoloadBunfig),
    ...renderBoolean("compile-autoload-tsconfig", o.autoloadTsconfig),
    ...renderBoolean("compile-autoload-package-json", o.autoloadPackageJson),
    ...(o.windows?.hideConsole === true ? ["--windows-hide-console"] : []),
    ...(o.windows?.icon === undefined ? [] : [`--windows-icon=${o.windows.icon}`]),
    ...(o.windows?.title === undefined ? [] : [`--windows-title=${o.windows.title}`]),
    ...(o.windows?.publisher === undefined ? [] : [`--windows-publisher=${o.windows.publisher}`]),
    ...(o.windows?.version === undefined ? [] : [`--windows-version=${o.windows.version}`]),
    ...(o.windows?.description === undefined ? [] : [`--windows-description=${o.windows.description}`]),
    ...(o.windows?.copyright === undefined ? [] : [`--windows-copyright=${o.windows.copyright}`]),
    `--outfile=${out}`,
    ...input.entrypoints,
  ];
};

const prepareBuild = Effect.fnUntraced(function*(
  operation: string,
  input: { readonly entrypoints: readonly string[]; readonly cwd?: string | undefined },
  output?: string,
) {
  if (input.entrypoints.length === 0) {
    return yield* new Tool.InputInvalid({ operation, reason: "entrypoints are empty" });
  }
  for (const entrypoint of input.entrypoints) {
    const issue = Tool.argumentIssue(entrypoint);
    if (issue !== undefined) return yield* new Tool.InputInvalid({ operation, reason: `entrypoint ${issue}` });
  }
  const outputIssue = output === undefined ? undefined : Tool.argumentIssue(output);
  if (outputIssue !== undefined) return yield* new Tool.InputInvalid({ operation, reason: `output ${outputIssue}` });
  if (input.cwd?.includes("\0")) return yield* new Tool.InputInvalid({ operation, reason: "cwd must contain no NUL" });
  const { tool } = yield* Bun;
  for (const constraint of constraints[operation] ?? []) yield* Tool.check(tool, operation, constraint);
  return tool;
});

const outputPath = (output: string, cwd?: string) =>
  Effect.map(Path.Path, (p) => p.resolve(cwd ?? "", output));

/**
 * `bun build --compile` as an Effect. Verifies the produced binary's header
 * against the requested target before returning it.
 */
export const compile = Effect.fn("Bun.compile")(function*(
  input: CompileInput,
): Effect.fn.Return<
  Artifact.Executable,
  CompileError,
  Bun | FileSystem.FileSystem | Path.Path | ChildProcessSpawner.ChildProcessSpawner
> {
  const tool = yield* prepareBuild("Bun.compile", input, input.outfile);
  const requested = input.target;
  const bunTarget = requested === undefined ? undefined : toBunTarget(requested);
  if (bunTarget !== undefined && !BunTarget.literals.includes(bunTarget)) {
    return yield* new Tool.InputInvalid({ operation: "Bun.compile", reason: `unsupported Bun target: ${requested}` });
  }
  // Omit --target for a native build: Bun knows its own host ABI, even when our
  // orchestrator cannot establish libc (for example Bun on Alpine).
  const target = bunTarget === undefined ? undefined : toTarget(bunTarget);
  const suffix = target === undefined ? (process.platform === "win32" ? ".exe" : "") : Target.parts(target).executableSuffix;
  if (suffix !== "" && !input.outfile.endsWith(suffix)) {
    // Bun always names Windows outputs *.exe, so the caller's outfile must too.
    return yield* new Tool.InputInvalid({
      operation: "Bun.compile",
      reason: `outfile for ${target ?? "the Windows host"} must end with ${suffix}`,
    });
  }
  const produce = (out: string) =>
    Tool.run(tool, renderArgv(input, out, bunTarget), { env: input.env, extendEnv: input.extendEnv, scrubEnv: input.scrubEnv, cwd: input.cwd, onOutput: input.onOutput }).pipe(
      Effect.andThen(Artifact.executable(out, Tool.producedBy(tool), target)),
    );
  const outfile = yield* outputPath(input.outfile, input.cwd);
  return yield* Commit.output(outfile, produce, input);
});

export type Loader = "js" | "jsx" | "ts" | "tsx" | "json" | "toml" | "yaml" | "text" | "file"
  | "dataurl" | "base64" | "css" | "html" | "sqlite" | "wasm" | "napi";

export interface BundleOptions extends Omit<CompileOptions,
  "sourcemap" | "execArgv" | "autoloadDotenv" | "autoloadBunfig" | "autoloadTsconfig" | "autoloadPackageJson" | "windows"> {
  readonly target?: "browser" | "bun" | "node" | undefined;
  readonly format?: "esm" | "cjs" | "iife" | undefined;
  readonly sourcemap?: "linked" | "inline" | "external" | "none" | undefined;
  readonly splitting?: boolean | undefined;
  readonly publicPath?: string | undefined;
  readonly root?: string | undefined;
  readonly loader?: Readonly<Record<string, Loader>> | undefined;
  readonly naming?: { readonly entry?: string | undefined; readonly chunk?: string | undefined; readonly asset?: string | undefined } | undefined;
  readonly banner?: string | undefined;
  readonly footer?: string | undefined;
  readonly metafile?: string | undefined;
  readonly drop?: readonly string[] | undefined;
  readonly features?: readonly string[] | undefined;
  readonly tsconfig?: string | undefined;
  readonly reactFastRefresh?: boolean | undefined;
  readonly bundle?: boolean | undefined;
}

export interface BundleInput extends Commit.ProducerOptions, Tool.EnvironmentOptions {
  readonly entrypoints: readonly [string, ...string[]];
  readonly outdir: string;
  readonly cwd?: string | undefined;
  readonly options?: BundleOptions | undefined;
  readonly onOutput?: Tool.RunOptions["onOutput"] | undefined;
}

export interface BuildInput extends Tool.EnvironmentOptions {
  readonly entrypoints: readonly [string, ...string[]];
  readonly cwd?: string | undefined;
  readonly onOutput?: Tool.RunOptions["onOutput"] | undefined;
  readonly options?: (Omit<BundleOptions, "bytecode" | "metafile" | "sourcemap" | "splitting"> & {
    readonly sourcemap?: "inline" | "none" | undefined;
  }) | undefined;
}

const renderBundleOptions = (o: BundleOptions): string[] => [
  ...(o.target === undefined ? [] : [`--target=${o.target}`]),
  ...(o.format === undefined ? [] : [`--format=${o.format}`]),
  ...(o.sourcemap === undefined ? [] : [`--sourcemap=${o.sourcemap}`]),
  ...(o.splitting === true ? ["--splitting"] : []),
  ...(o.packages === undefined ? [] : [`--packages=${o.packages}`]),
  ...(o.external ?? []).map((value) => `--external=${value}`),
  ...(o.conditions ?? []).map((value) => `--conditions=${value}`),
  ...(o.publicPath === undefined ? [] : [`--public-path=${o.publicPath}`]),
  ...(o.root === undefined ? [] : [`--root=${o.root}`]),
  ...Object.entries(o.define ?? {}).flatMap(([key, value]) => ["--define", `${key}=${value}`]),
  ...Object.entries(o.loader ?? {}).flatMap(([extension, loader]) => ["--loader", `${extension}:${loader}`]),
  ...(o.naming?.entry === undefined ? [] : [`--entry-naming=${o.naming.entry}`]),
  ...(o.naming?.chunk === undefined ? [] : [`--chunk-naming=${o.naming.chunk}`]),
  ...(o.naming?.asset === undefined ? [] : [`--asset-naming=${o.naming.asset}`]),
  ...renderMinify(o.minify),
  ...(o.bytecode === true ? ["--bytecode"] : []),
  ...(o.banner === undefined ? [] : [`--banner=${o.banner}`]),
  ...(o.footer === undefined ? [] : [`--footer=${o.footer}`]),
  ...(o.metafile === undefined ? [] : [`--metafile=${o.metafile}`]),
  ...(o.environmentInline === undefined ? [] : [`--env=${o.environmentInline}`]),
  ...(o.drop ?? []).flatMap((value) => ["--drop", value]),
  ...(o.features ?? []).flatMap((value) => ["--feature", value]),
  ...(o.tsconfig === undefined ? [] : ["--tsconfig-override", o.tsconfig]),
  ...(o.reactFastRefresh === true ? ["--react-fast-refresh"] : []),
  ...(o.bundle === false ? ["--no-bundle"] : []),
];

export const build = Effect.fn("Bun.build")(function*(input: BuildInput) {
  const tool = yield* prepareBuild("Bun.build", input);
  const result = yield* Tool.run(tool, ["build", ...renderBundleOptions(input.options ?? {}), ...input.entrypoints],
    { env: input.env, extendEnv: input.extendEnv, scrubEnv: input.scrubEnv, cwd: input.cwd, onOutput: input.onOutput, stdoutLimit: null });
  return result.stdout;
});

export const bundle = Effect.fn("Bun.bundle")(function*(input: BundleInput) {
  const tool = yield* prepareBuild("Bun.bundle", input, input.outdir);
  const outdir = yield* outputPath(input.outdir, input.cwd);
  const produce = (out: string) => Tool.run(tool,
    ["build", ...renderBundleOptions(input.options ?? {}), `--outdir=${out}`, ...input.entrypoints],
    { env: input.env, extendEnv: input.extendEnv, scrubEnv: input.scrubEnv, cwd: input.cwd, onOutput: input.onOutput }).pipe(
      Effect.andThen(Artifact.directory(out, Tool.producedBy(tool))),
    );
  return yield* Commit.output(outdir, produce, input, "sibling");
});

export interface WatchInput extends Omit<BundleInput, keyof Commit.ProducerOptions | "onOutput"> {
  readonly noClearScreen?: boolean | undefined;
  /** Inherit live diagnostics by default; use pipe to consume process streams. */
  readonly stdio?: "inherit" | "pipe" | undefined;
}

/** The caller owns the scope. Live diagnostics are inherited unless stdio is pipe. */
export const watch = Effect.fn("Bun.watch")(function*(input: WatchInput) {
  const tool = yield* prepareBuild("Bun.watch", input, input.outdir);
  const outdir = yield* outputPath(input.outdir, input.cwd);
  const process = yield* ChildProcess.make(tool.path, ["build", "--watch",
    ...(input.noClearScreen === true ? ["--no-clear-screen"] : []),
    ...renderBundleOptions(input.options ?? {}), `--outdir=${outdir}`, ...input.entrypoints], {
    cwd: input.cwd,
    ...yield* Tool.environment(tool, input),
    stdout: input.stdio ?? "inherit", stderr: input.stdio ?? "inherit",
    shell: false,
  }).pipe(Effect.mapError((e) => new Tool.SpawnFailed({ tool: tool.name, detail: String(e) })));
  return { tool, process, outdir };
});
