import { Context, Effect, FileSystem, Path, Redacted } from "effect";
import { Artifact, Commit, Executable, Tool } from "effect-build";
import { ChildProcessSpawner } from "effect/unstable/process";

export class Windows
  extends Context.Service<Windows, Tool.Service>()("effect-build-windows/Windows")
{}
type Env = FileSystem.FileSystem | Path.Path | ChildProcessSpawner.ChildProcessSpawner;
// SignTool's help has no version. Search its language-independent VS_FIXEDFILEINFO resource:
// https://learn.microsoft.com/en-us/windows/win32/api/verrsrc/ns-verrsrc-vs_fixedfileinfo
const productVersion = (contents: Uint8Array): string | undefined => {
  const view = new DataView(contents.buffer, contents.byteOffset, contents.byteLength);
  const key = "VS_VERSION_INFO\0";
  const header = { length: 0, valueLength: 2, type: 4, key: 6, value: 40, size: 92 } as const;
  const fixed = { size: 52, signature: 0, version: 4, productHigh: 16, productLow: 20 } as const;
  let version: string | undefined;
  // Resource data is DWORD-aligned, so the block can only start on a multiple of four.
  for (let offset = 0; offset + header.size <= contents.byteLength; offset += 4) {
    const length = view.getUint16(offset + header.length, true);
    if (
      length < header.size || offset + length > contents.byteLength
      || view.getUint16(offset + header.valueLength, true) !== fixed.size
      || view.getUint16(offset + header.type, true) !== 0
    ) continue;
    if (!Array.from(key).every((char, i) => view.getUint16(offset + header.key + i * 2, true) === char.charCodeAt(0))) {
      continue;
    }
    const value = offset + header.value;
    if (
      view.getUint32(value + fixed.signature, true) !== 0xfeef04bd
      || view.getUint32(value + fixed.version, true) !== 0x10000
    ) continue;
    const high = view.getUint32(value + fixed.productHigh, true);
    const low = view.getUint32(value + fixed.productLow, true);
    const native = [high >>> 16, high & 0xffff, low >>> 16, low & 0xffff].join(".");
    // Two resources that disagree cannot name the SDK; the layer reports that no single version exists.
    if (version !== undefined && version !== native) return undefined;
    version = native;
  }
  return version;
};
const provider = Tool.provider(Windows, {
  name: "signtool", versionArgs: ["/?"],
  version: {
    supported: ">=10.0.26100 <11.0.0", tested: ["10.0.26100"],
    parse: ({ path }) => Effect.gen(function*() {
      const contents = yield* FileSystem.FileSystem.use((fs) => fs.readFile(path)).pipe(
        Effect.mapError((error) => new Tool.ProbeFailed({ tool: "signtool", path, detail: String(error) })),
      );
      const native = productVersion(contents);
      if (native === undefined) return yield* new Tool.ProbeFailed({ tool: "signtool", path, detail: "no single VS_FIXEDFILEINFO ProductVersion resource" });
      return native;
    }),
  },
  requirements: { env: ["SystemRoot", "USERPROFILE", "TEMP", "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET"], network: true,
    services: ["Windows certificate store", "RFC3161 timestamp service", "Azure Trusted Signing"],
    detail: "Credentials select the certificate store, a PFX, or Trusted Signing; every signature obtains a timestamp." },
});
export const { name, supported, tested, constraints, requirements, resolved, testLayer } = provider;
/** String ranges select SDK families; predicates receive the complete four-component native version. */
export const layer = (options: Tool.LayerOptions = {}) => {
  const version = options.version ?? supported;
  return provider.layer({ ...options, version: typeof version === "function" ? version : (native) => Tool.satisfies(version)(native.split(".").slice(0, 3).join(".")) });
};

export type Credential = {
  readonly kind: "pfx";
  readonly file: string;
  readonly password?: Redacted.Redacted<string> | undefined;
} | {
  readonly kind: "store";
  readonly thumbprint: string;
  readonly storeName?: string | undefined;
  readonly machineStore?: boolean | undefined;
} | {
  /** Azure Trusted Signing: SignTool loads the client library and account metadata; Azure identity comes from the environment. */
  readonly kind: "trusted-signing";
  readonly library: string;
  readonly metadata: string;
};
export type SignInput<A extends Artifact.Regular = Artifact.Regular> = Credential & Commit.ProducerOptions & Tool.EnvironmentOptions & {
  readonly artifact: A;
  readonly outfile?: string | undefined;
  readonly cwd?: string | undefined;
  readonly timestampUrl: string;
  readonly description?: string | undefined;
  readonly descriptionUrl?: string | undefined;
};
export interface Signature {
  readonly fileDigest: "SHA256";
  readonly timestampProtocol: "RFC3161";
  readonly timestampDigest: "SHA256";
  readonly timestampUrl: string;
  readonly verification: "Authenticode";
}
export type Signed<A extends Artifact.Regular = Artifact.Regular> = A & { readonly signature: Signature };
export type SignError =
  | Tool.InputInvalid
  | Artifact.ArtifactError
  | Executable.InspectError
  | Executable.TargetMismatch
  | Tool.Failed
  | Tool.SpawnFailed
  | Commit.CommitError;
const urlValid = (value: string, httpsOnly: boolean): boolean => {
  if (
    Tool.argumentIssue(value) !== undefined || /\s/u.test(value) || value.includes("?") || value.includes("#")
    || !URL.canParse(value)
  ) return false;
  const url = new URL(value);
  return (url.protocol === "https:" || (!httpsOnly && url.protocol === "http:")) && url.hostname.length > 0
    && url.username === "" && url.password === "";
};
const invalid = (reason: string) => new Tool.InputInvalid({ operation: "Windows.sign", reason });

export function sign(
  input: SignInput<Artifact.Executable>,
): Effect.Effect<Signed<Artifact.Executable>, SignError, Windows | Env>;
export function sign(input: SignInput<Artifact.File>): Effect.Effect<Signed<Artifact.File>, SignError, Windows | Env>;
export function sign(input: SignInput): Effect.Effect<Signed, SignError, Windows | Env>;
export function sign(input: SignInput): Effect.Effect<Signed, SignError, Windows | Env> {
  return Effect.gen(function*() {
    const output = input.outfile ?? input.artifact.path;
    const extension = input.artifact.kind === "executable" ? ".exe" : ".msix";
    if (
      input.artifact.kind === "executable"
      && (input.artifact.format !== "pe" || !input.artifact.target.startsWith("windows-"))
    ) {
      return yield* invalid("executable artifacts must use PE and target Windows");
    }
    if (
      ![input.artifact.path, output].every((path) =>
        Tool.argumentIssue(path) === undefined && path.toLowerCase().endsWith(extension)
      )
    ) {
      return yield* invalid(`artifact and outfile must be non-empty ${extension} paths without NUL`);
    }
    if (
      !urlValid(input.timestampUrl, false)
      || (input.descriptionUrl !== undefined && !urlValid(input.descriptionUrl, true))
    ) {
      return yield* invalid(
        "timestampUrl must be HTTP(S) and descriptionUrl HTTPS, without credentials, whitespace, query, or fragment",
      );
    }
    if (
      [input.cwd, input.description].some((value) => value !== undefined && Tool.argumentIssue(value) !== undefined)
    ) {
      return yield* invalid("cwd and description must be non-empty strings without NUL");
    }
    const p = yield* Path.Path;
    const cwd = p.resolve(input.cwd ?? "");
    const outfile = p.resolve(cwd, output);
    const credential: string[] = [];
    let password: string | undefined;
    if (input.kind === "pfx") {
      if (Tool.argumentIssue(input.file) !== undefined) {
        return yield* invalid("PFX file must be a non-empty path without NUL");
      }
      credential.push("/f", p.resolve(cwd, input.file));
      if (input.password !== undefined) {
        password = yield* Effect.try({
          try: () => Redacted.value(input.password!),
          catch: () => invalid("PFX password is unavailable"),
        });
        if (password.includes("\0")) return yield* invalid("PFX password must not contain NUL");
        credential.push("/p", password);
      }
    } else if (input.kind === "store") {
      if (
        !/^[0-9a-f]{40}$/iu.test(input.thumbprint)
        || (input.storeName !== undefined && Tool.argumentIssue(input.storeName) !== undefined)
      ) {
        return yield* invalid(
          "store credentials require a 40-digit SHA-1 thumbprint and a non-empty store name without NUL",
        );
      }
      if (input.machineStore === true) credential.push("/sm");
      if (input.storeName !== undefined) credential.push("/s", input.storeName);
      credential.push("/sha1", input.thumbprint);
    } else {
      if ([input.library, input.metadata].some((path) => Tool.argumentIssue(path) !== undefined)) {
        return yield* invalid("Trusted Signing credentials require non-empty library and metadata paths without NUL");
      }
      credential.push("/dlib", p.resolve(cwd, input.library), "/dmdf", p.resolve(cwd, input.metadata));
    }
    const { tool } = yield* Windows;
    const produce = (out: string) =>
      Effect.gen(function*() {
        // Sign a copy and inspect the resulting executable before commit.
        yield* Artifact.copy(input.artifact, out);
        if (input.artifact.kind === "executable") {
          const target = input.artifact.target;
          yield* Executable.inspect(out).pipe(
            Effect.flatMap((facts) => Executable.resolveTarget(out, facts, target)),
            Effect.mapError((error) => new Artifact.ArtifactError({ path: out, reason: "invalid-metadata", detail: String(error) })),
          );
        }
        yield* Tool.run(tool, [
          "sign",
          "/fd",
          "SHA256",
          "/tr",
          input.timestampUrl,
          "/td",
          "SHA256",
          ...(input.description === undefined ? [] : ["/d", input.description]),
          ...(input.descriptionUrl === undefined ? [] : ["/du", input.descriptionUrl]),
          ...credential,
          out,
        ], { env: input.env, extendEnv: input.extendEnv, scrubEnv: input.scrubEnv, cwd, redact: password === undefined ? [] : [password] });
        yield* Tool.run(tool, ["verify", "/pa", "/all", "/v", "/tw", out], {
          env: input.env, extendEnv: input.extendEnv, scrubEnv: input.scrubEnv, cwd,
          redact: password === undefined ? [] : [password],
        });
        return yield* input.artifact.kind === "executable"
          ? Artifact.executable(out, Tool.producedBy(tool), input.artifact.target)
          : Artifact.file(out, Tool.producedBy(tool));
      });
    const artifact = yield* Commit.output(outfile, produce, input);
    return {
      ...artifact,
      signature: {
        fileDigest: "SHA256",
        timestampProtocol: "RFC3161",
        timestampDigest: "SHA256",
        timestampUrl: input.timestampUrl,
        verification: "Authenticode",
      },
    };
  });
}
